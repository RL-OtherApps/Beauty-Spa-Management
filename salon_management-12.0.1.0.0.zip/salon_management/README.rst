Beauty Spa Management v12
=========================
This Spa management system developed by Cybrosys Techno Solutions helps
your customers to do the online booking for using the service. This module
integrates with other Odoo modules like accounting and website.

Features
========
* Online Booking Facility.
* Accounting Facility.
* Customer Notification Through Mail.
* User Interactive Dashboard
* Customer Can view the Available chairs and order details
* Different access levels for Users and Administrator
* Track the chair user by date.


Credits
=======
Developer (v9-v12): AVINASH N K